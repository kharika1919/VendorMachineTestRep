using NUnit.Framework;
using System.Collections.Generic;
using VendorMachine;

namespace NUnitTestProject1
{
    public class Tests
    {
        Machine m;
        [SetUp]
        public void Setup()
        {
             m = new Machine();
            m.AddProducts();
            m.AddCoins();
        }

        [Test]
        public void Test1()
        {

            string productName = "Cola";
            List<string> coinsLst = new List<string> { "quarters", "quarters", "quarters", "quarters" };
            Assert.AreEqual(m.Display(productName,coinsLst),"Thank You");
        }

        [Test]
        public void Test2()
        {

            string productName = "Chips";
            List<string> coinsLst = new List<string> { "quarters", "nickels" };
            Assert.AreEqual(m.Display(productName, coinsLst), "Price: 0.5");
        }
        [Test]
        public void Test3()
        {

            string productName = "Cola";
            List<string> coinsLst = new List<string> {  };
            Assert.AreEqual(m.Display(productName, coinsLst), "Insert Coin");
        }
    }
}