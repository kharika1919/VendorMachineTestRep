﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendorMachine
{
    public class Product
    {
        private String m_ProductName;
        private double m_ProductPrice;

        public string ProductName
        {
            get
            {
                return m_ProductName;
            }
            set
            {
                m_ProductName = value;
            }
        }
        public double ProductPrice
        {
            get
            {
                return m_ProductPrice;
            }
            set
            {
                m_ProductPrice = value;
            }
        }

        
    }
}
