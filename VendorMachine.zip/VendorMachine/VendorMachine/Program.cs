﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VendorMachine
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Machine m = new Machine();
            m.Setup();
           
        }
        
    }

   
    
}
