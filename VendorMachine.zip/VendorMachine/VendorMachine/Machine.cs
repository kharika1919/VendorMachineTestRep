﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VendorMachine
{
    public class Machine
    {

        private List<Product> productsLst;
        private Dictionary<string, double> coins;
        public void Setup()
        {
            AddProducts();
            AddCoins();
            while (true)
            {
              VendorMachine();
            }
        }
        public void VendorMachine()
        {
            string InsertedCoin;
            List<string> coinsLst = new List<string>();
            Console.WriteLine("Please Select Product");
            var productName = Console.ReadLine();
            Console.WriteLine("Please Insert Coins, After Coins Insertion Please Enter Display");
            do
            {
                InsertedCoin = Console.ReadLine();
                coinsLst.Add(InsertedCoin);
            }
            while (InsertedCoin != "Display");
            coinsLst.RemoveAt(coinsLst.Count - 1);
            Display(productName, coinsLst);
        }
        public void AddProducts()
        {
            productsLst = new List<Product>();

            Product cola = new Product();
            cola.ProductName = "Cola";
            cola.ProductPrice = 1.00;
            productsLst.Add(cola);

            Product chips = new Product();
            chips.ProductName = "Chips";
            chips.ProductPrice = 0.50;
            productsLst.Add(chips);

            Product candy = new Product();
            candy.ProductName = "Candy";
            candy.ProductPrice = 0.65;
            productsLst.Add(candy);

        }

        public void AddCoins()
        {
            coins = new Dictionary<string, double>();
            coins.Add("nickels", 0.05);
            coins.Add("dimes", 0.1);
            coins.Add("quarters", 0.25);
        }

        public string Display(string name, List<string> coinsInserted)
        {
            String returnString;
            if (string.IsNullOrEmpty(name) || coinsInserted == null || coinsInserted.Count() == 0)
                returnString="Insert Coin";
            else
            {
                Product selectedProduct = productsLst.Where(x => x.ProductName == name).FirstOrDefault();
                if (selectedProduct != null)
                {
                    var rejectedCoins = coinsInserted.Where(x => coins.All(p => p.Key != x)).ToList();
                    var removedCount = coinsInserted.RemoveAll(x => rejectedCoins.Contains(x));
                    if (removedCount > 0)
                        returnString="Coins Placed in coin Return:" + removedCount;
                    double TotalValue = 0;
                    foreach (var insertedCoin in coinsInserted)
                    {
                        TotalValue += coins.GetValueOrDefault(insertedCoin);
                    }
                    if (TotalValue < selectedProduct.ProductPrice)
                        returnString="Price: " + selectedProduct.ProductPrice;
                    else
                        returnString="Thank You";

                }

                else
                {
                    returnString="ProductName is not Valid";
                }

            }
            Console.WriteLine(returnString);
            Console.WriteLine("---------------------------------------");
            return returnString;
            
        }
    }
}
